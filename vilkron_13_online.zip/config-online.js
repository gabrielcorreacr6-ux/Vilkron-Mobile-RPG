/* ============================================================
   CONFIGURAÇÃO DO MODO ONLINE (Supabase)
   Cole aqui os dois valores do seu projeto:
   Supabase > Project Settings > API (ou "Data API" / "API Keys")
     url   = Project URL         (ex.: https://abcdxyz.supabase.co)
     chave = anon public key     (começa com eyJ... ou sb_publishable_...)
   A chave "anon/publishable" pode ficar pública: quem protege os dados
   são as regras do arquivo supabase.sql. NUNCA cole a "service_role"/"secret".
   Enquanto estiver vazio, o jogo roda sozinho (offline), como antes.
   ============================================================ */
window.ONLINE = {
  url: 'https://xzkgbmtivrigwrmmlphu.supabase.co',
  chave: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh6a2dibXRpdnJpZ3dybW1scGh1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMzNzM2NDcsImV4cCI6MjEwODk0OTY0N30._S7HPQfm_TfAyCCI66L5eGpz3DnwmyMmOiPXbHhBK3U'
};
